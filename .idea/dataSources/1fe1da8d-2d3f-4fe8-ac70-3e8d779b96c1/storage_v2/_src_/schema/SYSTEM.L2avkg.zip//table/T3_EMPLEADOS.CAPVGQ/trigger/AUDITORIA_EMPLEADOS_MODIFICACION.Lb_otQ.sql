create trigger AUDITORIA_EMPLEADOS_MODIFICACION
    after update
    on T3_EMPLEADOS
    for each row
DECLARE
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN 
    INSERT INTO T3_auditoria_empleados (fecha,descripcion) VALUES (SYSDATE, 'REGISTRO DE ACTUALIZACION DE DATOS (UPDATE): Los nuevos valores se muestran como (nuevo)-(viejo). Id: ('||:NEW.id||')-('||:OLD.id||') Nombre: ('||:NEW.nom||')-('||:OLD.nom||') Sexo: ('||:NEW.sexo||')-('||:OLD.sexo||') Nacimiento: ('||:NEW.fecnac||')-('||:OLD.fecnac||') Ingreso: ('||:NEW.fecingreso||')-('||:OLD.fecingreso||') Salario: ('||:NEW.salario||')-('||:OLD.salario||') Comision: ('||:NEW.comision||')-('||:OLD.comision||') Cargo: ('||:NEW.cargo||')-('||:OLD.cargo||') Jefe: ('||:NEW.jefe||')-('||:OLD.jefe||') Departamento: ('||:NEW.coddep||')-('||:OLD.coddep||').');
    COMMIT;
END;
/

