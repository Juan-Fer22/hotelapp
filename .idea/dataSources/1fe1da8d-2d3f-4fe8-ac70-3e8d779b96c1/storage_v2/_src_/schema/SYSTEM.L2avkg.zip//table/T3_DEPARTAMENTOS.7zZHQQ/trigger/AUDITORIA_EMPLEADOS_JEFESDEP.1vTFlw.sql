create trigger AUDITORIA_EMPLEADOS_JEFESDEP
    after update
    on T3_DEPARTAMENTOS
    for each row
DECLARE
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN 
    IF :NEW.coddirector!=:OLD.coddirector THEN
        INSERT INTO T3_auditoria_empleados (fecha,descripcion) VALUES (SYSDATE, 'REGISTRO DE ACTUALIZACION DE JEFES (UPDATE): Los nuevos valores se muestran como (nuevo)-(viejo). Codigo del director: ('||:NEW.coddirector||')-('||:OLD.coddirector||') Codigo del departamento: '||:NEW.coddep||'.');
        COMMIT;
    END IF;
END;
/

