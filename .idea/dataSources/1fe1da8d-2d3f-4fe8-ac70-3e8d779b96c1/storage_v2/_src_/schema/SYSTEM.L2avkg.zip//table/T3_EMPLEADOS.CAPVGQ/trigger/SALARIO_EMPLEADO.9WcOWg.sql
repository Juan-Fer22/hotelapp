create trigger SALARIO_EMPLEADO
    after update of SALARIO
    on T3_EMPLEADOS
    for each row
DECLARE
    mensaje VARCHAR2(500);
BEGIN
    IF ( ( ( ( :OLD.salario * 5 ) / 100 ) + :old.salario ) >= :NEW.salario ) THEN
        mensaje := ( 'SE INCREMENTO EL SALARIO EN UN 5% O MAS.' );
        INSERT INTO T3_AUDITORIA_EMPLEADOS (
            fecha,
            descripcion
        ) VALUES (
            sysdate,
            mensaje
        );
    END IF;
END;
/

