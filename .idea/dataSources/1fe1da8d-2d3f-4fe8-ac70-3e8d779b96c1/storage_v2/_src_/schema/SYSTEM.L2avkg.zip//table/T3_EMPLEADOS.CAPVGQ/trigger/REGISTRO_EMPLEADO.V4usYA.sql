create trigger REGISTRO_EMPLEADO
    after insert or delete
    on T3_EMPLEADOS
    for each row
DECLARE
    mensaje VARCHAR2(500);
    PRAGMA autonomous_transaction;
BEGIN
    CASE
        WHEN inserting THEN
            mensaje := ( 'SE INSERTO AL EMPLEADO '
                         || :NEW.nom
                         || ' CON ID '
                         || :NEW.id );

            INSERT INTO T3_auditoria_empleados (
                fecha,
                descripcion
            ) VALUES (
                sysdate,
                mensaje
            );

        WHEN deleting THEN
            mensaje := ( 'SE ELIMINO AL EMPLEADO '
                         || :OLD.nom
                         || ' CON ID '
                         || :OLD.id );

            INSERT INTO T3_auditoria_empleados (
                fecha,
                descripcion
            ) VALUES (
                sysdate,
                mensaje
            );

    END CASE;
END;
/

