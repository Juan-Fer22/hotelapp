create view T1_P1 as
(SELECT Modelo FROM Productos WHERE tipo = 'laptop')
/

